import utest._

object Test extends TestSuite{

    val tests = Tests{
        'sumOfDivBy3Or - {
            assert(Exercises.sumOfDivBy3Or(iFrom = 1, iTo = 5) == 8)
            assert(Exercises.sumOfDivBy3Or(iFrom = 1, iTo = 9) == 17)
            }
    }
}


