import utest._

object Test extends TestSuite{

    val tests = Tests{
        'test_sumOfDivBy3Or - {
            assert(Exercises.sumOfDivBy3Or(iFrom = 1, iTo = 3) == 3)
            assert(Exercises.sumOfDivBy3Or(iFrom = 1, iTo = 5) == 8)
        }
    }
}


